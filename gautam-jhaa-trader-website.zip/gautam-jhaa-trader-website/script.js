// Lightweight interaction: add a click event for analytics integrations.
document.querySelectorAll('.telegram-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    // If you use an analytics platform, fire your approved event here.
    console.log('Telegram CTA clicked');
  });
});
